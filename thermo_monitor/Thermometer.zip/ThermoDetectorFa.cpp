

#include "ThermoDetectorFa.h"


namespace ThermoSpace{

ThermoDetectorFa::ThermoDetectorFa()
{
}

ThermoDetectorFa::~ThermoDetectorFa()
{
}

float ThermoDetectorFa::Read()
{
    // return detected value;
    return 0.1; 
}

};

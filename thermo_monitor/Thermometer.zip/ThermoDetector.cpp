
#include "ThermoDetector.h"

namespace ThermoSpace{

ThermoDetector::ThermoDetector()
{
}

ThermoDetector::~ThermoDetector()
{
}

};
